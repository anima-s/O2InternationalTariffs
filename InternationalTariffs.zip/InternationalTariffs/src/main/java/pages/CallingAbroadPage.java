package pages;

import base.CommonMethods;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class CallingAbroadPage extends CommonMethods {
    WebDriver driver;

    String payMonthly = "//a[@id='paymonthly']";
    String callingAbroadHeader = "//div[@id='content']/h2";
    String countryNameInput = "//input[@id='countryName']";
    String countryFlag = "//div[@id='countryFlag']/img[contains(@src,'ind.png')]";
    String selectCountryLink = "//a[@id='showAllCountries']";
    String countriesIframe = "//iframe[@id='destination_publishing_iframe_telefonicauklimited_0']";
    String selectCountryPopUp = "//div[@id='showBox']";
    String countryName = "India";
    String countryNameLink = "//div[@id='countryLinkContainer']//a[text()='country_name']";

    public CallingAbroadPage(WebDriver driver){
        this.driver=driver;
    }

    public void verifyCallingAbroadPageDisplayed(){
        Assert.assertEquals(getElement(callingAbroadHeader).getText(),"How much does it cost to call or text abroad?");
    }

    public void clickOnShowAllCountriesLink(){
        getElement(selectCountryLink).click();
        WebDriverWait wait = new WebDriverWait(driver, 1000);
        WebElement element = wait.until(ExpectedConditions.visibilityOf(getElement(selectCountryPopUp)));
        element.click();
    }

    public void clickOnCountryLink(String country){
        countryName = country;
        String link = countryNameLink.replace("country_name",country);
        getElement(link).click();

        WebDriverWait wait = new WebDriverWait(driver, 1000);
        wait.until(ExpectedConditions.visibilityOf(getElement(countryNameInput)));
        Assert.assertTrue(getElement(countryFlag).isDisplayed());
    }

    public void clickOnPayMonthlyTab(){
        WebElement payMonthlyTab = getElement(payMonthly);
        if(payMonthlyTab.isDisplayed()) payMonthlyTab.click();
    }

}
