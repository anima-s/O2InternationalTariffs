package pages;

public class PayAsYouGoPage {
}
