package pages;

import base.CommonMethods;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;


public class PayMonthlyPage extends CommonMethods {
    WebDriver driver ;

    String country = "India";
    String tabHeader = "//div[@id='paymonthlyTariffPlan']/h2[.=randomText]";
    String standardRatesLabel = "//div[@id='standardRates']//b[.='Standard Rates']";
    String countryFlagImage = "//div[@id='standardRates']//img[@alt='"+country+"']";
    String landlineLabel = "//table[@id='standardRatesTable']//tr[1]/td[text()='Landline']";
    String mobilesLabel = "//table[@id='standardRatesTable']//tr[2]/td[text()='Mobiles']";
    String textMessageLabel = "//table[@id='standardRatesTable']//tr[3]/td[text()='Cost per text message']";
    String landlineTariff = "//table[@id='standardRatesTable']/tbody/tr[1]/td[2]";
    String mobilesTariff = "//table[@id='standardRatesTable']/tbody/tr[2]/td[2]";
    String textMessageTariff = "//table[@id='standardRatesTable']/tbody/tr[3]/td[2]";
    String payAsYouGoSection = "//div[@id='payandgoTariffPlan']/div[@id='propositionContainer']";

    public PayMonthlyPage(WebDriver driver){
        this.driver = driver;
    }

    public void verifyStandardRatesSection(String country, String landlineTariffs, String mobilesTariffs, String textMessageTariffs){
        this.country = country;
        String header = tabHeader.replace("randomText","'Available rates when calling or texting "+country+"...'");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,0)");

        assert getElement(header).isDisplayed();
        assert getElement(header).isDisplayed();
        assert getElement(standardRatesLabel).isDisplayed();
        assert getElement(countryFlagImage).isDisplayed();
        assert getElement(landlineLabel).isDisplayed();
        assert getElement(mobilesLabel).isDisplayed();
        assert getElement(textMessageLabel).isDisplayed();
        Assert.assertEquals(getAmountValue(getElement(landlineTariff).getAttribute("innerHTML")),landlineTariffs);
        Assert.assertEquals(getAmountValue(getElement(mobilesTariff).getAttribute("innerHTML")),mobilesTariffs);
        Assert.assertEquals(getAmountValue(getElement(textMessageTariff).getAttribute("innerHTML")),textMessageTariffs);

        //Verify Pay As You Go Section not displayed here
        Assert.assertFalse(getElement(payAsYouGoSection).isDisplayed());
    }
}
