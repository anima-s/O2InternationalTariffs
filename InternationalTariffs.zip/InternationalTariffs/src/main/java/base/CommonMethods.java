package base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CommonMethods {
    public static WebDriver driver;

    public WebDriver getChromeDriverInstance(){
        System.setProperty("webdriver.chrome.driver","chromedriver");
        driver = new ChromeDriver();
        return driver;
    }

    public void gotoTravelAbroadPage(WebDriver driver){
        driver.navigate().to("http://international.o2.co.uk/internationaltariffs/travelling_abroad#");
        String currentWindow = driver.getWindowHandle();
        driver.switchTo().window(currentWindow);
        driver.manage().window().maximize();
    }

    public void gotoCallingAbroadPage(WebDriver driver){
        driver.navigate().to("http://international.o2.co.uk/internationaltariffs/calling_abroad_from_uk");
        String currentWindow = driver.getWindowHandle();
        driver.switchTo().window(currentWindow);
        driver.manage().window().maximize();
    }

    public void closeSession(WebDriver driver){
        driver.quit();
    }

    public WebElement getElement(String locatorStrategy ,String locator){
        WebElement ele;

        locatorStrategy = (locatorStrategy==null || locatorStrategy.length()<3) ? "xpath" : "css";
        ele = (locatorStrategy=="xpath") ? driver.findElement(By.xpath(locator)) : driver.findElement(By.cssSelector(locator));

        return ele;
    }

    public WebElement getElement(String locator){
        return driver.findElement(By.xpath(locator));
    }

    public String getAmountValue(String value){
        String amount="0";
        if(value.contains("p"))
            amount = value.split("p")[0];
        else if(value.contains("£"))
            amount = value.split("£")[1];

        return amount;

    }
}
