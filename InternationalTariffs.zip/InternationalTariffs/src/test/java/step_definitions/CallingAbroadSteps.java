package step_definitions;


import base.CommonMethods;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import pages.CallingAbroadPage;
import pages.PayMonthlyPage;

public class CallingAbroadSteps extends CommonMethods{
    WebDriver driver = getChromeDriverInstance();
    PayMonthlyPage payMonthlyPage = new PayMonthlyPage(driver);
    CallingAbroadPage callingAbroadPage = new CallingAbroadPage(driver);

    @Given("^I am on Calling abroad home page$")
    public void i_am_on_Calling_abroad_page()  {
        gotoCallingAbroadPage(driver);
        callingAbroadPage.verifyCallingAbroadPageDisplayed();
    }

    @When("^I click on show all countries link$")
    public void i_click_on_show_available_countries_link() {
        callingAbroadPage.clickOnShowAllCountriesLink();
    }

    @And("^I select \"(.*)\" from the available countries$")
    public void i_select_country_from_the_available_countries(String country) {
        callingAbroadPage.clickOnCountryLink(country);
    }

    @And("^I click on Pay Monthly tab$")
    public void i_click_on_Pay_Monthly_tab() {
        callingAbroadPage.clickOnPayMonthlyTab();
    }

    @Then("^I should be able to see the tariffs for (.*)")
    public void i_should_be_able_to_see_the_tariffs_for_selected_country(String country) {
        payMonthlyPage.verifyStandardRatesSection("India","2.00","2.00","55");

        //Close session after tests
        closeSession(driver);
    }

}
